import { loadHeaderFooter } from "./utils.mjs";

loadHeaderFooter();